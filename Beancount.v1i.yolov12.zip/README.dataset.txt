# Beancount > 2025-04-13 9:58pm
https://universe.roboflow.com/ddd-aiw7a/beancount

Provided by a Roboflow user
License: CC BY 4.0

